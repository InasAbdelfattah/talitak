<a href=""
   class="btn btn-icon btn-xs waves-effect btn-default m-b-5">
    <i class="fa fa-edit"></i>
</a>

<a href="javascript:;" id="elementRow" data-id=""
   class="removeElement btn btn-icon btn-trans btn-xs waves-effect waves-light btn-danger m-b-5">
    <i class="fa fa-remove"></i>

</a>